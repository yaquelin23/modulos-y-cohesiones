// Módulo de Empleado
class Empleado {
    constructor(nombre, salario, departamento) {
      this.nombre = nombre;
      this.salario = salario;
      this.departamento = departamento;
    }
    
    // Métodos para obtener y establecer información del empleado
    // Métodos para calcular bonificaciones, etc.
  }
  
  // Módulo de Departamento
  class Departamento {
    constructor(nombre) {
      this.nombre = nombre;
      this.empleados = [];
    }
    
    // Métodos para agregar, eliminar y listar empleados del departamento
    // Métodos para calcular el salario total del departamento, etc.
  }
  
  // Módulo de Gestión
  function agregarEmpleadoADepartamento(empleado, departamento) {
    departamento.empleados.push(empleado);
  }
  
  function calcularSalarioTotalDepartamento(departamento) {
    let salarioTotal = 0;
    for (let empleado of departamento.empleados) {
      salarioTotal += empleado.salario;
    }
    return salarioTotal;
  }
  
  // Ejemplo de uso
  const empleado1 = new Empleado("Juan", 3000, "Ventas");
  const empleado2 = new Empleado("María", 3500, "Marketing");
  
  const departamentoVentas = new Departamento("Ventas");
  agregarEmpleadoADepartamento(empleado1, departamentoVentas);
  agregarEmpleadoADepartamento(empleado2, departamentoVentas);
  
  console.log(calcularSalarioTotalDepartamento(departamentoVentas));

